#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <strings.h>
#include <stdbool.h>

bool* flag;
int i=0;
int j=1;
int turn;

void increment()
{
	flag[j] = true;
	turn = i;
	while(flag[i] == true && turn == i);
	key_t key = ftok("/home/examuser/", 45);
	int shmid = shmget(key, 1024, IPC_CREAT | 0660);
	int *arr = (int*) shmat(shmid, 0, 0);
	int x = arr[0];
	x+=10;
	arr[0] = x;
	shmdt(arr);
	flag[j] = false;
}

void decrement()
{
	sleep(1);
	flag[i] = true;
	turn = j;
	while(flag[j] == true && turn == j);
	key_t key = ftok("/home/examuser/", 45);
	int shmid = shmget(key, 1024, IPC_CREAT | 0660);
	int *arr = (int*) shmat(shmid, 0, 0);
	int x = arr[0];
	x-=10;
	arr[0] = x;
	shmdt(arr);
	flag[i] = false;
}

int main(int argc, char* argv[])
{
	key_t key = ftok("/home/examuser/", 45);
	int shmid = shmget(key, 1024, IPC_CREAT | 0660);
	int *arr = (int*) shmat(shmid, 0, 0);
	int x = 0;
	arr[0] = x;
	shmdt(arr);
	pid_t pid = fork();
	if(pid == 0)
	{
		increment();
	}
	else
	{
		pid_t pid1 = fork();
		if(pid1 == 0)
		{
			decrement();
		}
		else
		{
			wait(NULL);
			key = ftok("/home/examuser/", 45);
			shmid = shmget(key, 1024, IPC_CREAT | 0660);
			arr = (int*) shmat(shmid, 0, 0);
			x = arr[0];
			printf("The final value of x is: %d \n", x);
			shmdt(arr);
			shmctl(shmid, IPC_RMID, NULL);
		}
	}
	return 0;
}
